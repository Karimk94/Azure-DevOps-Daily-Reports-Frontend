:HL["/daily-reports/_next/static/chunks/55a78e2d886db3cf.css","style"]
0:{"buildId":"o9MKash0t2Ts9BQS9icuT","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
