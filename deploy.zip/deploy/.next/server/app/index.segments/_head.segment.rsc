1:"$Sreact.fragment"
2:I[97367,["/daily-reports/_next/static/chunks/f795227749618145.js"],"ViewportBoundary"]
3:I[97367,["/daily-reports/_next/static/chunks/f795227749618145.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/daily-reports/_next/static/chunks/f795227749618145.js"],"IconMark"]
0:{"buildId":"o9MKash0t2Ts9BQS9icuT","rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"RTA Dashboard"}],["$","meta","1",{"name":"description","content":"Daily Operations Report"}],["$","link","2",{"rel":"icon","href":"/daily-reports/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],null]}],"loading":null,"isPartial":false}
