var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/[...proxy]/route.js")
R.c("server/chunks/[root-of-the-server]__d37d46e7._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_[___proxy]_route_actions_62e6d3ab.js")
R.m(82145)
module.exports=R.m(82145).exports
