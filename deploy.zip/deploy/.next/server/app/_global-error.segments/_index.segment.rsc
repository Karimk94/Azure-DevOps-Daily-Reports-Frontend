1:"$Sreact.fragment"
2:I[39756,["/daily-reports/_next/static/chunks/f795227749618145.js"],"default"]
3:I[37457,["/daily-reports/_next/static/chunks/f795227749618145.js"],"default"]
0:{"buildId":"o9MKash0t2Ts9BQS9icuT","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
